#!/bin/sh
if [ ! -e /dev/rtc0 ]; then
    modprobe i2c-bcm2708
    modprobe i2c-dev
    modprobe rtc-ds1307
    for bus in $(ls -d /sys/bus/i2c/devices/i2c-*); do
		echo ds1307 0x68 >> $bus/new_device
		if [ -e /dev/rtc0 ]; then
			break;
		fi
		echo 0x68 >> $bus/delete_device
    done
fi
case "$1" in
	start)
		hwclock -s
		;;
	stop)
		hwclock -w
		;;
	status|reload|restart)
		hwclock -r
		;;
	*)
		echo "Usage: slam-clock.sh start|stop"
		exit 1
esac
exit 0
